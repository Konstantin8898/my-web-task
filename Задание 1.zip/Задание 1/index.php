<?=
$title = "PHP";
$page_title = "general page";
$content = "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, nulla? 
Soluta placeat voluptates labore architecto est, voluptatum recusandae facere natus! Quo 
ratione quas aperiam animi magni culpa aliquam accusamus veniam?";
include("components/layout.php");
?>